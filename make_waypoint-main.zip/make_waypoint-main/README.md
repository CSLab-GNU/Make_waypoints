# Make waypoint
